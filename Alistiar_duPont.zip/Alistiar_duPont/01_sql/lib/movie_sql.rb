require 'singleton'
require 'sqlite3'

class MovieDatabase < SQLite3::Database
  include Singleton

  def initialize
    super(File.dirname(__FILE__) + "/../movie.db")

    self.results_as_hash = true
    self.type_translation = true
  end

  def self.execute(*args)
    self.instance.execute(*args)
  end
end

# 1. Obtain the cast list for the movie "Top Gun"; order by the
# actor's name.
def top_gun_cast
  MovieDatabase.execute(<<-SQL)
  SELECT actors.name
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE movies.title = 'Top Gun'
  ORDER BY actors.name
SQL
end

# 2. List the films in which 'Harrison Ford' has appeared; order by
# movie title.
def harrison_ford_films
  MovieDatabase.execute(<<-SQL)
  SELECT movies.title
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE actors.name = 'Harrison Ford'
  ORDER BY movies.title
SQL
end

# 3. For each film released in 2000 or later in which 'Christopher
#    Walken' has appeared, list the movie title and the year. Order by
#    movie title.
def christopher_walken_21st_century_films
  MovieDatabase.execute(<<-SQL)
  SELECT movies.title, movies.yr
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE actors.name = 'Christopher Walken' AND movies.yr >= 2000
  ORDER BY movies.title
SQL
end

# 4. List the films together with the leading star for all films
# produced in 1910. Order by movie title.
def leading_star_for_1910_films
  MovieDatabase.execute(<<-SQL)
  SELECT movies.title, actors.name
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE movies.yr = 1910 AND castings.ord = 1
  ORDER BY movies.title
SQL
end

# 5. There is a film from 2012 in our database for which there is no
# associated casting information. Give the id and title of this movie.
def unknown_actors_2012
  MovieDatabase.execute(<<-SQL)
  SELECT movies.title, movies.id
  FROM movies
  LEFT OUTER JOIN castings ON movies.id = castings.movie_id
  WHERE movies.yr = 2012 AND castings.movie_id IS NULL
SQL
end

# 6. Which films have more than 60 roles? List the movie title and
# number of roles. Order by movie title.
def big_movies
  MovieDatabase.execute(<<-SQL)
  SELECT movies.title, count(actors.name) AS roles
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  GROUP BY castings.movie_id
  HAVING COUNT(actors.name) > 60
  ORDER BY movies.title
SQL
end
# I grouped by movies.title instead of castings.movie_id. Couldn't see that there may be more than one move with the same title. 



# 7. List the movie year, movie title, and supporting actor (ord = 2)
# for all of the films in which Will Smith played the star role
# (ord = 1). Order by the name of the supporting actor.
def will_smith_supporting_actors
  MovieDatabase.execute(<<-SQL)
  SELECT movies.yr, movies.title, actors.name
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE castings.ord = 2 AND castings.movie_id IN (
  SELECT castings.movie_id
  FROM actors
  JOIN castings ON castings.actor_id = actors.id
  JOIN movies ON movies.id = castings.movie_id
  WHERE actors.name = 'Will Smith' AND castings.ord = 1
  )
  ORDER BY actors.name
SQL
end

# 8. There is a movie in which 'Barrie Ingham' plays two roles. Write a
# query that returns the title of this movie.
def barrie_ingham_multiple_roles
  MovieDatabase.execute(<<-SQL)
    SELECT
      movies.title
    FROM
      movies
    JOIN
      castings ON castings.movie_id = movies.id
    JOIN
      actors ON castings.actor_id = actors.id
    WHERE
      actors.name = 'Barrie Ingham'
    GROUP BY
      movies.title
    HAVING
      COUNT(actors.id) = 2
SQL
end
# # ran out of time to finish this one off. Spent way too mich time on the #6 here and the two specs on the other part of the test.
# 
#   SELECT
#     movies.title
#   FROM
#     actors AS actors1
#   JOIN
#     castings AS first_cast ON first_cast.actor_id = actors1.id
#   JOIN
#     movies  ON movies.id = first_cast.movie_id
#   JOIN
#     castings AS second_cast ON movies.id = second_cast.movie_id
#   JOIN
#     actors As actors2 ON second_cast.actor_id = actors2.id
#   WHERE
#     actors1.name = 'Barrie Ingham' AND
#     actors2.name = 'Barrie Ingham' AND
#     first_cast.ord != second_cast.ord