# Make sure to be looking at the specs and the `db/schema.rb`. Part of
# your job is to be able to understand the structure and interrelations
# of the data from these sources.

# We provide a brief overview. There are Employees (e.g., Jim). Employees
# belong to a Company (Jim works at Google) and are assigned to work at a
# specific Campus (an office location) at their Company (Jim works at the
# Mountain View Campus at Google). A Company is led by a CEO (an
# Employee), and a Campus is overseen by a campus manager (an Employee).

# Employees are assigned to work on one or more Projects. The Project is
# led by a project manager (an Employee).

# Lastly, Employees have a Computer. Reflecting the personal bond between
# Employee and Computer, a Employee has but a single Computer.# 

# == Schema Information
# #
# Table name: campuses
#
#  id                :bigint           not null, primary key
#  name              :string
#  address           :string
##  company_id        :integer
##  campus_manager_id :integer
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#

class Campus < ApplicationRecord
  self.table_name = 'campuses' # otherwise Rails looks for a 'campus' table

    belongs_to :campus_manager, 
    primary_key: :id, 
    foreign_key: :campus_manager_id, 
    class_name: 'Employee'

    belongs_to :company, 
    primary_key: :id, 
    foreign_key: :company_id, 
    class_name: 'Company'

    has_many :employees, 
    primary_key: :id, 
    foreign_key: :campus_id, 
    class_name: 'Employee'

end

