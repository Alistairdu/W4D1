# == Schema Information
#
# Table name: projects
#
#  id                 :bigint           not null, primary key
#  title              :string
#  description        :string
##  project_manager_id :integer
#  created_at         :datetime         not null
#  updated_at         :datetime         not null
#

class Project < ApplicationRecord
    has_many :assignments, 
    primary_key: :id, 
    foreign_key: :project_id, 
    class_name: 'ProjectAssignment'

    belongs_to :project_manager, 
    primary_key: :id, 
    foreign_key: :project_manager_id, 
    class_name: 'Employee'

    has_many :programmers, 
    through: :assignments, 
    source: :programmer
    
    has_one :company, 
    through: :project_manager,
    source: :company
end

