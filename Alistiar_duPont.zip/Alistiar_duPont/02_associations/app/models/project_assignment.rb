# == Schema Information
#
# Table name: project_assignments
#
#  id            :bigint           not null, primary key
##  programmer_id :integer
##  project_id    :integer
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#

class ProjectAssignment < ApplicationRecord
    belongs_to :programmer, 
    primary_key: :id, 
    foreign_key: :programmer_id,
    class_name: 'Employee'

    belongs_to :project, 
    primary_key: :id, 
    foreign_key: :project_id, 
    class_name: 'Project'

    
end

