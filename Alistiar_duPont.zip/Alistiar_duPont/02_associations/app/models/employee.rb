# == Schema Information
#
# Table name: employees
#
#  id         :bigint           not null, primary key
#  fname      :string
#  lname      :string
##  campus_id  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Employee < ApplicationRecord
    has_one :managed_campus, 
    primary_key: :id, 
    foreign_key: :campus_manager_id, 
    class_name: 'Campus'

    has_one :ceo, 
    primary_key: :id, 
    foreign_key: :ceo_id, 
    class_name: 'Company'

    has_one :computer, 
    primary_key: :id, 
    foreign_key: :owner_id, 
    class_name: 'Computer'

    belongs_to :campus, 
    primary_key: :id, 
    foreign_key: :campus_id, 
    class_name: 'Campus'

    has_many :project_assignments, 
    primary_key: :id, 
    foreign_key: :programmer_id,
    class_name: 'ProjectAssignment'

    has_many :projects_led, 
    primary_key: :id, 
    foreign_key: :project_manager_id, 
    class_name: 'Project'

    has_many :programmers, 
    through: :campus, 
    source: :employees
    
    has_one :company, 
    through: :campus, 
    source: :company
    
    has_one :campus_manager, 
    through: :campus, 
    source: :campus_manager

    
    has_many :projects, #only trid this route for the project managers, not the projets. Dman. ;D
    through: :project_assignments, 
    source: :project
    
    # this one relied on the next one I missed, AND i missed the one above as I already tested the project assignments below. Faceplant. 
    # end of the day I needed to think this through better. 
    has_many :project_managers, # WROTE DOWN THESE NOTES IN THE TEST: # NOT through projects Led, or Project Assignments, or campus
    through: :projects, 
    source: :project_manager
    




end

